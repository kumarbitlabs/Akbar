/* JFM1T11_Assignment3:

   Have you ever arranged the deck of cards, or maybe shirts in your cupboard? What is common between those two things? 
   Well, you put the next card or shirt into their proper position, or we can say you insert the next element in its 
   proper position. Write a program to sort an unsorted array of numbers in the same manner.
   Prompt the user input from the terminal.

   SampleInput: 6,5,4,3,2,1
   
   Expected Output: 1,2,3,4,5,6

*/

import java.util.Scanner;
public class InsertionSort {
   //main method
   public static void main(String[] args) {
     //declare variables
     int n,i;
     //take input from user
     Scanner sc = new Scanner(System.in);
     //create integer array for all elements
     System.out.print("Enter number of elements in the array:");
     n = sc.nextInt();
     int a[] = new int[n];
     System.out.println("Enter "+n+" elements: ");
     for( i=0; i < n; i++){
       a[i] = sc.nextInt();
     }
     //call sort method
     Sort(a);
     //print sorted array
     System.out.println("elements after sorting");
     printarray(a);
  }
    //create sort method
   public static void Sort(int a[]){
     //declare variables
     int n=a.length,i,j,p,temp;
     // storing current element whose left side is checked for its correct position 
     for (i = 1; i < n; i++) { 
     //check whether the adjacent element in left side is greater or less than the current element.
       for (j=i-1; j >=0 && a[j+1]<a[j]; j--){ 
       // move the left side element to one position forward.
         temp=a[j+1];
         a[j+1]=a[j];
       // move current element to its  correct position.
         a[j]=temp;
       } 
     } 
  }
  //print array
  public static void printarray(int a[]){
     for(int i=0; i < a.length; i++){
       System.out.print(a[i]+" ");
     }
  }
}


 









