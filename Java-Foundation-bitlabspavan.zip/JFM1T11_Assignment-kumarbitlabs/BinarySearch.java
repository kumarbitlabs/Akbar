/* JFM1T11_Assignment2:

   Write a program to execute the search of a number in a sorted array following the below logic: 
   If the target element is greater than middle element then you go to the middle of the right of the remaining numbers 
   or otherwise towards middle of the left of the remaining numbers. 
   Continue until the number is either found or not found.
   Prompt the user input from the terminal.
   
   Sample Input: 2,5,10,12,15,20,25,31,40
   Enter number to search x= 20

   Expected Output: Position of element is : 6
   
   Enter number to search x= 26
   Expected Output: Sorry,Key doesn't exist in the array
   
*/

import java.util.Scanner;
public class BinarySearch {
   //main method 
  public static void main(String args[]){
     //Declare variables  
     int key, n;
     //take input from user
     Scanner sc = new Scanner(System.in);
     System.out.print("Enter number of elements in the array: ");    
     n = sc.nextInt();
     int arr[] = new int[n];
     System.out.println("Enter "+n+" elements in ascending order:");
     for(int i=0; i < n; i++){
      arr[i] = sc.nextInt();
     }
     System.out.println("Enter number to search =");
     key = sc.nextInt();
    // beg = 0;
    // end=arr.length-1;
     //call binarySearch method
     binarySearch(arr,key);     
   }   
  //create a method in that declare a variables and initialize l=a.length, beg=0, end=l-1, mid=(beg+end)/2 
  public static void binarySearch(int arr[], int key){
    int beg = 0;
    int end = arr.length-1;
     int mid = (beg + end)/2; 
     //check each number less than or greater than to the mid element
     while( beg <= end ){ 
      //if mid element is less than key than it calculates beg and mid  
      if ( arr[mid] < key ){  
        beg = mid + 1; 
      //if mid is equal to key than it stops and return mid 
      }
      else if ( arr[mid] == key ){  
        System.out.println("Position of element is: " +(mid+1));  
        break;
      //if mid element is greater than key then it calculates end and mid  
      }
      else{  
         end = mid - 1;  
      }  
      mid = (beg + end)/2;  
     }
     //checking beg is greater than end, then mid = 0
     if ( beg > end ){  
      System.out.println("Sorry,Key doesn't exist in the array");  
     }  
   }  
}  






