/*  JFM1T11_Assignment5 :

    Write a program to sort an array containing negative, non-negative and zero values in descending order.
    Prompt the user input from the terminal.
    
    Sample Input: 2,-3,-1,4,-2
    
    Expected Output: -3,-2,-1,4,2
    
*/

import java.util.Scanner;  
public class RearrangePositiveNegative {
   //main method    
   public static void main(String[] args) {  
      int n, temp;
      //take input from user
      Scanner sc = new Scanner(System.in);  
      System.out.print("Enter the number of elements: ");  
      n = sc.nextInt();  
      int a[] = new int[n];  
      System.out.println("Enter the elements of the array: ");  
      for(int i = 0; i < n; i++) {  
        a[i] = sc.nextInt();
      }
      rearrange(a, n);
      printArray(a, n);
      //call descending method
      for (int i = 0; i < n; i++) {     
        for (int j = i+1; j < n; j++) {     
          if(a[i] < a[j]) {    
            temp = a[i];    
            a[i] = a[j];    
            a[j] = temp;    
          }     
       }     
     }    
   }
   //print result
   static void printArray(int a[], int n) {
     for (int i = 0; i < n; i++)
      System.out.print(a[i] + " ");
   }
   //create descending method
   static void rearrange(int a[], int n){
     //declare and initialize variables
     int j = 0, temp;
     //check each element if the element is less then zero and the both numbers are not equal  then it swaps them  
     for (int i = 0; i < n; i++) {
       if (a[i] < 0) {
         if (i != j) {
           temp = a[i];
           a[i] = a[j];
           a[j] = temp;
         }
     //increasing elements untill all elements rearranged            
        j++;
       }
     }
   }
}



           









