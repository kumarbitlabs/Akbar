/* JFM1T11_Assignment6:

   Write a program to sort an array containing alphabets, special symbols and numbers.
   Prompt the user input from the terminal.
   
   Sample Input: bit01$$Lab02s03!@!!
   
   Expected Output: 
   Characters: bitLabs
   Numbers: 010203
   Special characters: $$!@!!

*/

import java.util.Scanner;
public class Spliting { 
 //main method
 public static void main(String args[]) {
       // take input from user
       Scanner sc = new Scanner(System.in);
       String str;
       System.out.println("Enter input");
       str = sc.nextLine();
       //call splitString method
       splitString(str);
    }
 //create splitString method in that initialize characters, numbers and specialcharacters to stringBuffer
 static void splitString(String str) {
        StringBuffer characters = new StringBuffer(); 
        StringBuffer numbers = new StringBuffer(); 
        StringBuffer specialcharacters = new StringBuffer();
        //check if the entered string is digit,alpha, numbers and characters using if condition
        for (int i=0; i<str.length(); i++) {
         if (Character.isDigit(str.charAt(i)))
            numbers.append(str.charAt(i));
         else if(Character.isAlphabetic(str.charAt(i)))
            characters.append(str.charAt(i));
         else
            specialcharacters.append(str.charAt(i));
        }
        //printing seperatly characters in character, numbers in number and special characters in special character
        System.out.println("Characters: " + characters);
        System.out.println("Numbers: " + numbers);
        System.out.println("Special characters: " + specialcharacters);
   }
}


     
     



