/* JFM1T10_Assignment5:

     Write a program to access a protected method of a class in different package. 

     Sample Output:
     Try to access the protected method outside the package using inheritance
    
*/


//Outside the folder create ProtectedMethod class and import the package1
import package1.package1;
public class ProtectedMethod{
   //Define main method
  public static void main(String args[]){
    // Access and print x of Demo class   
     package1 obj = new package1();
      obj.msg();
  }
}