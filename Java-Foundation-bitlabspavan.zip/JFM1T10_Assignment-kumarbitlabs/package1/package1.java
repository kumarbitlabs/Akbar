//Create a folder called package1

package package1;
//Inside the folder create a Demo class with the package name as package1. In that define a protected variable
public class package1{
    public void msg(){
        System.out.println("Try to access the protected method outside the package using inheritance");
    }
}

