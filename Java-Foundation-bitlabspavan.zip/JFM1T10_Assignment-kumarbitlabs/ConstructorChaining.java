/* JFM1T10_Assignment1:

   Write a program to demonstrate Constructor chaining in Java 
   Add atleast 3 constructors




   Sample Output:
   Parent class default constructor
   Child class default constructor
   Parent class one-argument constructor
   Child class one-argument constructor

*/

//parent class   
class Demo {  
//parent class default constructor  
  Demo() {  
   this(80, 90);  
   System.out.println("Parent class default constructor");  
  }  
//parent class one-argument constructor  
  Demo(int x, int y) {  
   System.out.println("Parent class one-argument constructor");  
  }  
}  
// child class  
class Prototype extends Demo {  
//child class default constructor  
  Prototype() {  
   this("Java", "Python");  
   System.out.println("Child class default constructor");  
  }  
//child class one-argument constructor  
  Prototype(String str1, String str2) {  
   super();  
   System.out.println("Child class one-argument constructor");  
  }  
}  
public class ConstructorChaining {  
 //main method  
  public static void main(String args[]) {   
  //initializes the instance of example class  
   Prototype myexample = new Prototype();  
  }   
}








