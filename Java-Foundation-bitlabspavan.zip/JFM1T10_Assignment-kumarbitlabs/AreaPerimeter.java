/* JFM1T10_Assignment3:

     Create an abstract class Shape with following data member and methods- 
     Create data members for height and width.
     Add getter and setter methods for height and width.
     Create methods for finding area and perimeter.
     Create three subclasses Square, Rectangle and EquilateralTriangle that extends Shape class and define both the methods.
     Write a program that will find the area and perimeter of 3 Shapes and print the details for all. 
     Prompt the user for the  values to be input from the terminal.
 
     Sample Input:
     Enter Width of Rectangle in meters
     10
     Enter Length of Rectangle in meters
     5
     Enter width of Equilateraltriangle
     15
     Enter radius of circle
     60

     Expected Output:
     Rectangle width: 10.0 meters and length: 5.0 meters
     Resulting area: 50.0 square meters
     Resulting perimeter: 30.0 meters 

     EquiTriangle side: 15.0meters
     Resulting area: 97 square meters
     Resulting perimeter: 45.0 meters 

     Circle radius : 60.0meters
     Resulting area: 11310 square meters
     Resulting perimeter: 377 meters  

*/
import java.util.Scanner;
 abstract class Shape{
  public abstract double area();
  public abstract double perimeter();
 }
//Add Rectangle class that extends Shape class
 class Rectangle extends Shape{
  private final double width,length; //sides
  public Rectangle(){
    this(1,1);
  }  
  public Rectangle(double width, double length){
    this.width=width;
    this.length=length;
  }
  public double area(){
    return width * length;
  }
  public double perimeter(){
   //p=2(w+l)
    return 2*(width+length);
  }
}
//Add Circle class that extends Shape class
class Circle extends Shape{
  double pi = 3.14;
  private final double radius;
  public Circle() {
    this(1);
  }   
  public Circle(double radius){
    this.radius=radius;
  }
  public double area(){
    return pi * Math.pow(radius,2);
  }
  public double perimeter(){
    return 2 * pi * radius;
  }
}
//Add Equitriangle class that extends shape class
class  EquiTriangle extends Shape{
  private final double a;
  public EquiTriangle() {
    this(1);
  }
  public EquiTriangle(double a){
    this.a = a;
  }
  public double area(){
    double s = 3*(a)/2;
    return Math.sqrt(s*(s - a)*(s - a)*(s - a));
  }
  public double perimeter(){
    return 3 * a;
  }
}

class AreaPerimeter {
//Add the main method here and find Area and Perimeter 
public static void main(String[] args){
  //Use the scanner class to provide height and width at execution time
  /*
  Scanner s= new Scanner(System.in);
  System.out.println("Enter the height of triangle");
  EquilateralTriangle triangle=new EquilateralTriangle();
  triangle.setHeight(s.nextInt());
  */
  Scanner sc = new Scanner(System.in);
  // Rectangle test
  System.out.println("Enter the width of rectangle in meters");
  double width = sc.nextDouble();
  System.out.println("Enter the length of rectangle in meters");
  double length = sc.nextDouble();
  Shape rectangle = new Rectangle(width , length);
  System.out.println("Resulting area: " + rectangle.area() + " square meters");
  System.out.println("Resulting perimeter: " + rectangle.perimeter() + " meters");
  
  // Circle test
  System.out.println("Enter the radius of circle");
  double radius = sc.nextDouble();
  Shape circle = new Circle(radius);
  System.out.println("Resulting Area: " + Math.round(circle.area()) + " square meters");
  System.out.println("Resulting Perimeter: " + Math.round(circle.perimeter()) + " meters");

  // EquiTriangle test
  System.out.println("Enter the width of equitriangle");
  double a = sc.nextDouble();
  Shape equitriangle = new EquiTriangle(a);
  System.out.println("Resulting Area: " + Math.round(equitriangle.area()) + " square meters");
  System.out.println("Resulting Perimeter: "+ equitriangle.perimeter() + " meters");
 }
}





