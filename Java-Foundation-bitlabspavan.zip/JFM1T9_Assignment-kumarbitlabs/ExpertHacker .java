/*JFM1T9_Assignment2:
    Write a BankAccount class with members account_number and account_balance  and prevent other class objects 
    (assuming them as hackers who can steal your confidential information) to access BankAccount details.
    Steps to Follow:
    Step1: Create account_number and account_balance as member variables for BankAccount class
    Step 2: Add setter and getter methods for the above member variables 
    
*/
import java.util.Scanner;
//creating a baseclass 'BankAccount'
class BankAccount { 
    //Declaration of variables 'account_number' , 'account_balance'
    private long account_number; 
    private double account_balance;  
    //creating a method 'setBankAccountNumber()'
    public void setBankAccountNumber(long newval) {
        this.account_number = newval;
        
    }
    //creating a method 'setBankAccountBalance()'
    public void setBankAccountBalance(double newval) {
        this.account_balance = newval;
    }
    //creating a method 'getAcNumber'
    public long getAcNumber() {
        return account_number;
    }
    //creating a method 'getAcBalance'
    public double getAcBalance() {
        return account_balance;
    }
}
    
 

class ExpertHacker { 

public static void main(String args[]) {
    
    Scanner input = new Scanner(System.in);
    //taking the input from the user
    System.out.print("Enter BankAccount Number : ");
    long bankAcNo = input.nextLong();
    input.nextLine();
    //taking the input from the user
    System.out.print("Enter Current Balance    : ");
    double bankAcBa = input.nextDouble();
// Try accessing fields of BankAcccount class and check whether it's accessible 
    BankAccount b = new BankAccount();
// or not. If not then try accessing it with it’s setter and getter methods. 
    b.setBankAccountNumber(bankAcNo);
    b.setBankAccountBalance(bankAcBa);
// Print account_number and account_balance 
    System.out.println("BankAccount Number : "+b.getAcNumber());
    System.out.println("Current Balance    : "+b.getAcBalance());
}   

} 

