/*JFM1T9_Assignment1:
    Write a program applying Encapsulation to age field in Person class that cannot be accessed directly from outside class
    but can be accessed using setter and getter methods. 
    Steps to follow:
    Step1: Add age attribute to the Person class 
    Step 2: Add setter and getter methods for the age attribute  
     
*/
import java.util.Scanner;
//creating a base class 'Person'
class Person {
    //Declaration of the variable 'age'
    private int age;
    //creating a method 'setAge()'
    public void setAge(int val) {
        age = val;
    }
    //creating a method 'getAge()'
    public int getAge() {
        return age;
    }
}
 

class PersonEncapsulation { 

public static void main(String args[]) { 

// Try accessing age field of Person directly and check whether it’s accessible
// or not.If not then try accessing it with it’s setter and getter methods. 
    Scanner input = new Scanner(System.in);
    System.out.print("Enter your age : ");
    int a = input.nextInt();
 
    Person p = new Person();
    p.setAge(a);
// Output age  
    
    System.out.println("Your age : "+p.getAge());
}   

} 

