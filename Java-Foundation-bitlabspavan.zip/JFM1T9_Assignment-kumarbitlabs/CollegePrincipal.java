/* JFM1T9_Assignment4:
     Extend and enhance the previous inheritance program where collegeName, designation and 
     work() method are common to all the teachers and declared in the base class in the way
     that all child classes like MathTeacher, EnglishTeacher and MusicTeacher do not need to 
     write this code and can use directly from base class. 
*/
//Add Teacher class
class Teacher {
     String collegename ="iit";
     String designation;
    
     public void work() {
          
          System.out.println(designation+ "      "+collegename);    
     }
     

}
//Add MathTeacher class
class MathTeacher extends Teacher {
     public MathTeacher() {
          designation = "Math Teacher   ";
     
}

}
//Add EnglishTeacher class
class EnglishTeacher extends Teacher {
     public EnglishTeacher() {
          designation = "English Teacher";
     
}

}
//Add MusicTeacher class
class MusicTeacher extends Teacher {
     public MusicTeacher() {
          designation = "Music Teacher  ";
     
}

}
public class CollegePrincipal {

//Add the main method here and create all different types of Teacher objects and print there college name designation.
     public static void main(String args[]){
          MathTeacher m = new MathTeacher();
          EnglishTeacher e = new EnglishTeacher();
          MusicTeacher mu = new MusicTeacher();
          m.work();
          e.work();
          mu.work();
     }

     }


