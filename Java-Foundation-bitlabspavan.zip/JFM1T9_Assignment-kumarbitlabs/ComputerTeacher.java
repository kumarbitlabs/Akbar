/* JFM1T9_Assignment3:
     Create a base class Teacher and a sub class ComputerTeacher.
     class ComputerTeacher extends the designation and collegename properties and work() method from base Teacher class,
     you need not declare these properties and method in ComputerTeacher sub class .
     Try accessing these properties using child class object in Main method.
*/

//creating a baseclass 'Teacher'
class Teachers {
     //initialization and declaration of varialbe 'collegename' and 'designation'
     String collegename ="iit";
     String designation="computerTeacher";
     //creating a method 'work()'
     public void work() {
          
          //prints the designation and CollegeName
          System.out.println("Designation       CollegeName");
          System.out.print(designation+ "      "+collegename);    
     }
     
}

class ComputerTeacher extends Teachers {
     public static void main(String args[]) {
          //initalization of the variabel 'designation'
          //designation = "computerTeacher";
               //creating an object 'c' for the baseclass      
               Teacher c = new Teacher();
               //c.designation = "computerTeacher";
               //calling a method by an object
               c.work();
}
}

