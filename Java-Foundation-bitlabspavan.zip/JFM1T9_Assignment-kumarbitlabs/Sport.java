/* JFM1T9_Assignment5:
	Create an object named obj of the class Main and print the reference to the object using this keyword.*/ 

//creating a base class 'Sport'
class  Sport { 

// Create a member variable for Sport name 
String cricket;
// Set member variable for Sport name 
public Sport(String val) {
    this.cricket = val; 
}


public static void main(String args[]) { 
        
// Create object for Sport class 
Sport s = new Sport("Cricket");
// Print the value of Sport name using "this" reference
System.out.println("Sport name : "+s.cricket);
} 

} 

