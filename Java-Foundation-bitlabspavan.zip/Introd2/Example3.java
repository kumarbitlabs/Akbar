//program to find the data type of primitive data type variable
public class Example3 
{    
  public static void main(String args[])
  {   
   double x = 78.9d;         System.out.println(((Object)x).getClass().getSimpleName()); 
  }
} 

/*
public class MyClass 
{     
  public static void main(String args[]) 
 {         
   String[] arr = new String[5];  
  System.out.println(arr.getClass().getSimpleName()); 
 } 
} 

*/