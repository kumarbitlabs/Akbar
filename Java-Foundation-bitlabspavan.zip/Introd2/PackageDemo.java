import intro.*;
public class PackageDemo {
  public static void main(String args[])
  {
    Ex1 m = new Ex1();
    m.display();
  }

}