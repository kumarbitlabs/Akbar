
public class Example4 
{    
  public static void main(String args[])
  {   
   //double d=75.3;
    //int a=(int)d;

    int a=67;
    double d=a;
    System.out.println(d);
    System.out.println(a);
  }
} 