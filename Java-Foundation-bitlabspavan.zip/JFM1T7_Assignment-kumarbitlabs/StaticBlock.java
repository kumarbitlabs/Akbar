/* JFM1T7_Assignment5:
   Write a program to create a static method named dispCollegeName to print the value of a static variable  college_name initialized using static block.
   Access this method from another class and display college_name for 3 students who study in same college.
   Prompt the user for the  values to be input from the terminal
   Sample Input:
   Enter the student name: Sri
   Enter the student Roll no: 1
   Enter the student name: Balaji
   Enter the student Roll no: 2
   Enter the student name: Ram
   Enter the student Roll no: 3
   
   Expected Output:
   Student name: Sri
   Student Roll no: 1
   College Name : IIT
   Student name: Balaji
   Student Roll no: 2
   College Name : IIT
   Student name: Ram
   Student Roll no: 3
   College Name : IIT
*/
import java.util.Scanner;
public class StaticBlock {
   //main method
   public static void main(String args[]) { 
      //initialize Student class constructor for three times
      Student x = new Student();
      Student y = new Student();
      Student z = new Student();
      //creating scanner object
      Scanner sc = new Scanner(System.in);
      //taking input from the user
      System.out.println("Enter the student name : ");
      //initializing string variables
      String h = sc.next();
      String h1 = sc.next();
      String h2 = sc.next();
      x.setName(h);
      y.setName(h1);
      z.setName(h2);
      System.out.println("Enter the student Roll no : ");
      //initializing int variable
      int a = sc.nextInt();
      int a1 = sc.nextInt();
      int a2 = sc.nextInt();
      x.setRollNo(a);
      y.setRollNo(a1);
      z.setRollNo(a2);
      //printing the output
      System.out.println("Student name : " + x.getName());
      System.out.println("Student Rollno : " + x.getRollNo());
      x.dispCollegename();
      System.out.println("Student name : " + y.getName());
      System.out.println("Student Rollno : " + y.getRollNo());
      y.dispCollegename();
      System.out.println("Student name : " + z.getName());
      System.out.println("Student Rollno : " + z.getRollNo());
      z.dispCollegename();
   }
}
//creating Student class and declaring variables
class Student {
   //creating staticBlock in that give collegename
   static String College_name = "IIT";
   //add getters and setters
   int rollNo;
   String name;
   //add  setter method for rollno
   public void setRollNo(int rollNum) {
      this.rollNo = rollNum; 
   } 
   //add getter method for rollno
   public int getRollNo() {
      return this.rollNo; 
   } 
   //add setters and getters for name fields also
   public void setName(String names) {
      this.name = names;
   }
   public String getName() {
      return this.name;
   }
   //creating dispCollegename static method
   public static void dispCollegename() {  
      System.out.println("College name : " + College_name);
   }
}