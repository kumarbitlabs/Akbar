/* JFM1T5_Assignment3:

   Write a program to store the temperature of your city for last 7 days and print the lowest temperature of the week.
   Prompt the user input from the terminal.
   
   Sample Input:
   Enter number of days 
   3
   Enter the temperature of Day :1
   88
   Enter the temperature of Day :2
   34
   Enter the temperature of Day :3
   0 
   
   Expected Output:
   The lowest temperature of the week 3 is 0.0 celsius

*/


import java.util.Scanner;

public class Temperature
{

         //Define the main method
          public static void main(String[] args)
        {
              //Declare the variables and initialize
               int n,index=0;
               Scanner sc=new Scanner(System.in);
               
              //Take temperature of 7 days as a input from user
               System.out.println("enter how many days");
               n= sc.nextInt();
               System.out.println("enter the temperatures of last "+ n+" days");
               float[] temp= new float[n];
               for(int i=0;i<n;i++)
                   temp[i]=sc.nextFloat();
              //Calculate the lowest temperature
               float lowTemp=temp[0];
               for(int i=0;i<n;i++)
               {
                  if(lowTemp>temp[i])
                  {
                    lowTemp=temp[i];
                    index =i+1;
                  }
                  
                       
               }
              //Print the result
               System.out.println("The lowest temperature of the week "+(index)+" is "+lowTemp);
        }


}