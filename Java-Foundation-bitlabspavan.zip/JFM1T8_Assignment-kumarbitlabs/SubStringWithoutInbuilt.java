/*  JFM1T8_Assignment3:

    Write a program to find a substring in a string without using an inbuilt method of String class.
    Prompt the user input from the terminal.
    
    Sample input: Learning made easy at bitLabs
    Enter search string: bitLabs
    
    Expected output: bitLabs is found
    
    Enter search string: bitlab
    Expected output: bitlab is not found

*/

import java.util.Scanner;
public class SubStringWithoutInbuilt {
  //main method
  public static void main(String args[]){
     //declare variables
     String s, sbr;
     //take input from user
     Scanner sc=new Scanner(System.in);
     System.out.println("Enter the String:");
     s=sc.nextLine();
     System.out.println("Enter search string :");
     sbr=sc.nextLine();
     //compare two strings if the search string found or not without using inbuilt method isSubString()
     //creat isSubString method in that declare variable 
     int n1 = s.length();
     int n2 = sbr.length();
     //check two strings if the search string is present then return true else return false 
     for (int i = 0; i <= n1 - n2; i++) {
       int j;
     for (j = 0; j < n2; j++) {
     if(s.charAt(i + j) != sbr.charAt(j))
        break;
     }
     if(j == n2) {
        System.out.println(sbr + " is found");
        return;
     }
     }
     System.out.println(sbr + " is not found");
  }
}










