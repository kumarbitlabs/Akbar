package intro;
public class Ex1 {
  public void display() {
    System.out.println("This is my package! i am happy class");
  }
}