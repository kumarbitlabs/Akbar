import java.lang.Math;
public class Ex2
{
  public static void main(String[] args)
  {
    int X = 9;
    double R = Math.sqrt(X);
    System.out.println("Welcome to java");
    System.out.println("The square root of " + X + " is " + R);

// The square root of 9 is 3.0
    //concatenation operator
  }
}

