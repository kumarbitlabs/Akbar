/*  JFM1T12_Assignment1:

    Write a program to search an element in an arraylist.  
    Prompt the user input from the terminal.
    
    Sample Input 1:
    Enter how many Elements you want: 
    5
    Enter Elements: 
    Red
    Green
    Orange
    White
    Black
    
    Enter Search Element: 
    Red
    
    Expected Output:
    Red Element is present

    Sample Input 2: 
    Enter Search Element: 
    yellow
    
    Expected Output:
    yellow Element is not present

*/

import java.util.Scanner;
import java.util.ArrayList; 
import java.util.LinkedHashSet;
public class SearchingElement {
  //main method
  public static void main(String args[]) {
    //declare variables
    int n;
    //create scanner object
    Scanner sc = new Scanner(System.in);
    //take input from user
    System.out.println("Enter how many Elements you want:");
    n = sc.nextInt();
    ArrayList<String> colors = new ArrayList<String>();
    System.out.println("Enter elements: ");
    for (int i = 0; i <= n; i++) {
       colors.add(sc.nextLine());
    }
    //creat an object of LinkedHashSet class 
    LinkedHashSet<String> listcolors = new LinkedHashSet<String>(colors);
    System.out.println("\nEnter search element:");
    String st=sc.nextLine();
    //check if the search element is present on the list using contains method
    if(listcolors.contains(st)) {
    //If element found then print element is present else then print element not present 
      System.out.println(st + " element is present");
    }
    else {
      System.out.println(st + " element is not present");
    }
  }
}
