/*  JFM1T12_Assignmwnt4:

    Write a Java program to reverse elements in an arraylist.
    Prompt the user input from the terminal.
     
    Sample Input:
    Enter how many numbers you want: 
    5
    Enter Number 0
    995
    Enter Number 1
    367
    Enter Number 2
    511
    Enter Number 3
    789
    Enter Number 4
    111
    
    Expected Output:
    Elements after reversing:111 789 511 367 995  

 */
import java.io.*;
import java.util.*; 
import java.util.ArrayList; 
public class ReverseArrayList  {  
   //Take an arraylist as a parameter and returns a reversed arraylist 
   public ArrayList<Integer>reverseArrayList(ArrayList<Integer>alist) {
      //Arraylist for storing reversed elements
      ArrayList<Integer> revArrayList = new ArrayList<Integer>();
      for(int i=alist.size() - 1; i >= 0; i--) {
        //Append the elements in reverse order 
        revArrayList.add(alist.get(i));
      }  
        //Return the reversed arraylist
        return revArrayList;
   }    
   //Iterate through all the elements and print
   public void printElements(ArrayList<Integer>alist) {
      for(int i=0; i < alist.size(); i++) {
        System.out.print(alist.get(i) + " ");
      }
   }
   //main method
   public static void main(String args[]) {
      //creat an object of ReverseArrayList class 
      ReverseArrayList obj = new  ReverseArrayList();
      //create scanner object
      Scanner sc = new Scanner(System.in);
      //creat an object of ArrayList class
      ArrayList<Integer> arrayli = new ArrayList<Integer>();
      //take input from user
      System.out.println("Enter how many numbers you want: ");
      int n = sc.nextInt();
      for (int i = 0; i < n; i++) {
        System.out.println("Enter number " + (i) + " : ");
        arrayli.add(sc.nextInt());
      }
      //call reverseArrayList method
      arrayli = obj.reverseArrayList(arrayli);
      //call printElements method
      System.out.println("\nElements after reversing:");
      obj.printElements(arrayli);
   }
}





