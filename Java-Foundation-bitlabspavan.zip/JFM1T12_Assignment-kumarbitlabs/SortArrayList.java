/*  JFM1T12_Assignment2:

    Write a program to sort a given arraylist of integers in ascending order.   
    Prompt the user input from the terminal.
    
    Sample Input:
    Enter how many numbers you want: 
    5
    Enter Number 0
    467
    Enter Number 1
    342
    Enter Number 2
    167
    Enter Number 3
    511
    Enter Number 4
    204
    
    Expected Output:
    ArrayList After Sorting:
    167
    204
    342
    467
    511

*/     

import java.util.*;  
import java.util.Collections;
public class SortArrayList  {  
  //main method
  public static void main(String args[]) {
     //declare variables
     int n;
     //create Scanner object
     Scanner sc = new Scanner(System.in);
     //take input from user
     System.out.println("Enter how many numbers you want:");
     n = sc.nextInt();
     //create an object of ArrayList class
     ArrayList<Integer> list = new ArrayList<Integer>();
     for (int i = 0; i < n; i++) {
        System.out.println("Enter number " + (i) + " : ");
        list.add(sc.nextInt());
     }
     //sort ArrayList in ascending oeder
     Collections.sort(list);
     //print Array list
     System.out.println("\nArrayList after sorting: ");
     for(int numbers:list){
      System.out.println(numbers);
     } 
   }
}  


