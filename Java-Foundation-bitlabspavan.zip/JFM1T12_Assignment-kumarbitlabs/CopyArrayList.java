/*   JFM1T12_Assignment3:

     Write a program to copy one arraylist into another.
     Prompt the user input from the terminal.
     
     Sample Input:
     Enter how many numbers you want: 
     5
     Enter Number 0
     5
     Enter Number 1
     4
     Enter Number 2
     3
     Enter Number 3
     2
     Enter Number 4
    
    Expected Output:
    -----Iterating over the second ArrayList----
     5
     4
     3
     2
     1

*/
import java.io.*;
import java.util.ArrayList; 
import java.util.Scanner;
public class CopyArrayList  { 
   //main method
   public static void main(String[] args){
        //declare variables
        int num;
        //create Scanner object
        Scanner sc = new Scanner(System.in);
        //take input from user
        System.out.println("Enter how many numbers you want: ");
        num = sc.nextInt();
        //creation of array list for integers
        ArrayList<Integer> al = new ArrayList<Integer>();
        //add() elements to first reference
        for (int i = 0; i < num; i++) {
          System.out.println("Enter number " + (i) + " : ");
          al.add(sc.nextInt());
        }
        // Assign the first reference to second
        ArrayList<Integer> al2 = al;
        // Iterat over second ArrayList and print
        System.out.println("\n-----Iterating over the second array list-----");
        for(Integer value: al2){
          System.out.println(value);
        }
    }
}    


