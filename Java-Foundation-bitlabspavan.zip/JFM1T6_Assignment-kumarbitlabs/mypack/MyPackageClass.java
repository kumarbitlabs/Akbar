package mypack;
public class MyPackageClass {
  public void display() {
    System.out.println("This is my package!");
  }
}