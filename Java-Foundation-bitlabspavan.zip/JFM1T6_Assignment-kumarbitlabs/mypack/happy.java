package mypack;
public class happy {
  public void display() {
    System.out.println("This is my package! i am happy class");
  }
}