/* JFM1T6_Assignment2:
   Write a method that takes 2 numbers as arguments/parameters and returns the value of num2 to the power of num1 back to the main method.
   Prompt the user for the base and power values to be input from the terminal.
   Sample input:
   num1 = 3
   num2 = 2
    
   Expected Output:
   result = 9
   
*/

import java.util.*;

public class Power 
{
   public static void main(String[] args)
   {
      Scanner sc = new Scanner(System.in);
      
      System.out.print("Enter Base Value = ");
      long baseNumber = sc.nextLong();
      
      System.out.print("Enter Power Value = ");
      int powerNumber = sc.nextInt();
      
      Power p = new Power();
      
      long result = p.Pow(baseNumber, powerNumber);
      
      System.out.print(baseNumber+"^"+powerNumber+" = "+ result);
      
      
   }
   
   long Pow(long base , int power)
   {
      
      
      if(base >= 0 && power == 0 )
      {
         return 1;
      }
      else if( base == 0 && power >= 1)
      {
         return 0;
      }
      else
     {
         
         long value = 1;
         for(int i=0; i < power ; i++)
         {
            value = base * value;
         }
         
         return value;
         
      }
      
      
   }


}
