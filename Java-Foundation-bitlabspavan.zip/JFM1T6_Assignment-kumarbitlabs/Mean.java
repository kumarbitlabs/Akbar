/* JFM1T6_Assignment3:
   Write a method that takes any numbers as arguments/parameters and return the mean value back to main method.
   Prompt the user for the  values to be input from the terminal.
   Sample input:
   num1 = 3
   num2 = 2
   num3 = 4
   Expected Output:
   result = 3
   
*/

import java.util.Scanner;
class CalculateMean
  {
    int sum=0;
     public float meanc(int a,int n)
    {
      sum+=a;
      float m=(float)sum/n;
      return m;
    }
  }
class Mean {
  public static void main(String [] args)
  {
    int n,a,i;
    float me=0;
    CalculateMean cm=new CalculateMean();
    Scanner s= new Scanner(System.in);
    System.out.println("Enter total number of numbers");
    n=s.nextInt();
    for(i=1;i<=n;i++)
      {
        System.out.print("num"+i+"= ");
        a=s.nextInt();
        me=cm.meanc(a,n);
        System.out.println();
      }
    System.out.println("Result mean = "+me);
  }
  
}