/* JFM1T13_Assignment1

     Write a program to create a priority queue, add some colors (string) and print out the elements of the priority queue. 
     Prompt the user input from the terminal.
     
     Sample Input: 
     Enter how many colors you want: 
     5
     Enter Colors: 
     red
     orange
     green
     white
     black
     
     Expected Output:
     Elements of the Priority Queue:  black, green, orange, red, white 
*/

import java.util.Scanner;
import java.util.PriorityQueue;
public class Priority {
  //maiin method
  public static void main(String args[]) {
     //Declare variables
     int n;
     //creat Scanner object
     Scanner sc = new Scanner(System.in);
     //initialize priority queue object
     PriorityQueue<String> pq = new PriorityQueue<String>();
     //take input from user and add that values to the priority queue object
     System.out.println("Enter how many colors you want:");
     n = sc.nextInt();
     System.out.println("Enter colors: ");
     for(int i=0; i<=n; i++) {
        pq.add(sc.nextLine());
     }
     //print result using poll method
     String head = pq.poll();
     System.out.println("\nElements of the Priority Queue: " + pq);
  }
}


