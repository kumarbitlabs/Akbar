/*    JFM1T13_Assignment5:  

      Create an application having a Generic HashMap with Empcode  as key and EmpName as value. Display only EmpNames as output. 
       Prompt the user input from the terminal.

      Sample Input: 
      Enter Emp code:101
      Enter Emp Name: Ram
      Enter another student (y/n)?y
      Enter Emp code:102
      Enter Emp Name: Vaibhav
      Enter another student (y/n)?y
      Enter Emp code:103
      Enter Emp Name: Priyanka
      Enter another student (y/n)?n

      Expected Output: 
        Ram
        Vaibhav
        Priyanka
       
*/
import java.util.Scanner;
import java.util.HashMap;
public class HashDemo {
  //main method
  public static void main(String args[]) throws InterruptedException {
     //Create scanner object
     Scanner sc = new Scanner(System.in);
     boolean loopAgain = true; 
     //declare the HashMap 
     HashMap <Integer,String> hm = new HashMap <Integer,String>();
     //create a while loop for user not enter no
     do {
        //ask for user input for value and key
        System.out.print("Enter Emp code:");
	    Integer Key = Integer.parseInt(sc.nextLine());
	    System.out.print("Enter Emp Name:");
	    String Value = sc.nextLine();
        //add the user inputs to the HashMap
        String oldVal = hm.put(Key, Value);
        if(oldVal!=null) {
	       System.out.println("Empolyee name:" + Value + " is " 
	         + oldVal + " and has been overwritten by " + Key);
        }  
        //ask user if they want to enter another student details
        System.out.print("Enter another employee (y/n)?");
        String answer = sc.nextLine();
        //condition to satisfy in order to loop again
        if (answer.equals("y") || answer.equals("Y")) {
	      continue;
        } 
        else {
          break;
        }
     }
     while(loopAgain);
     sc.close();
     System.out.println();
     //use for each loop to grab Emp code and Emp Name
     for(String EmpName : hm.values()){
         System.out.println(EmpName);
     }   
  }       
}

















