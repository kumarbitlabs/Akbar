/* JFM1T13_Assignment2:

     Write a program to iterate through all elements in an ArrayDeque.Using iterator method
     Prompt the user input from the terminal.
     
     Sample Input: 12,31,6,23,90

     Expected Output:  
     ArrayDeque: [12, 31, 6, 23, 90]
     The iterator values are: 
     12
     31
     6
     23
     90
*/

import java.util.Scanner;
import java.util.ArrayDeque;
import java.util.Iterator;
public class IteratorArrayDeque {
    //main method
    public static void main(String args[]) {
       //Declare variables
       int n;
       //create Scanner object
       Scanner sc = new Scanner(System.in);
       //create an empty ArrayDeque
       ArrayDeque<Integer> deque = new ArrayDeque<Integer>();
       //take input from user
       System.out.println("Enter how many numbers you want:");
       n = sc.nextInt();
       //add elements into the queue
       for (int i = 0; i < n; i++) {
          System.out.println("Enter number " + (i) + " : ");
          deque.add(sc.nextInt());
       }
       System.out.println("ArrayDeque: " + deque);
       //create an iterator
       Iterator value = deque.iterator();
       //Display the values after iterating through the Deque 
       System.out.println("The iterator values are: ");
       while (value.hasNext()) {
          System.out.println(value.next());
       }
    }    
}





