/*  JFM1T13_Assignment3:

      Write a Java program to count the number of key-value (size) mappings in a map. 
      Prompt the user input from the terminal.

      Sample Input: 
      Enter value:20
      Enter key:bitLabs
      Enter another student (y/n)?y
      Enter value:25
      Enter key:welcomes
      Enter another student (y/n)?y
      Enter value:30 
      Enter key:you
      Enter another student (y/n)?n

      Expected Output: The size of the map is 3
*/
import java.util.Scanner;
import java.util.HashMap;
public class MapCount {
  //main method
  public static void main(String args[]) throws InterruptedException {
    //Create scanner object
    Scanner sc = new Scanner(System.in);
    boolean loopAgain = true;
    //declare HashMap object
    HashMap <Integer,String> hm = new HashMap <Integer,String>();
    //create a while loop for user not enter no
    do {
      //ask for user input for value and key 
      System.out.print("Enter value:");
	    Integer Value = Integer.parseInt(sc.nextLine());
      System.out.print("Enter key:");
	    String Key = sc.nextLine();
	    //add the user inputs to the HashMap
      String oldVal = hm.put(Value, Key);
      if (oldVal!=null) {
	       System.out.println("Student number:" + Value + " is " 
	          + oldVal + " and has been overwritten by " + Key);
      }    
      //ask user if they want to enter another
      System.out.print("Enter another student (y/n)?");
      String answer = sc.nextLine();
      //condition to satisfy in order to loop again
      if (answer.equals("y") || answer.equals("Y")) {
	      continue;
      } 
      else {
        break;
      }
    }
    while(loopAgain);
    sc.close();
    //print total size as result
    System.out.println("\nThe size of the map is " + hm.size());
  }  
}




